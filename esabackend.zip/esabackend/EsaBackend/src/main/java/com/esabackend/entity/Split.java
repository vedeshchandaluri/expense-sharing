package com.esabackend.entity;

import jakarta.persistence.*;

@Entity
public class Split {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double amount;

    @ManyToOne
    private Expense expense;

    @ManyToOne
    private User user;

    // Getters and setters
}
