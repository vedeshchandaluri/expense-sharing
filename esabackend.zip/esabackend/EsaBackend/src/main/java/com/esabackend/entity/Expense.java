package com.esabackend.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
public class Expense {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String description;
    private double amount;
    private LocalDate date;

    @ManyToOne
    private User paidBy;

    @ManyToOne
    private Group group;

    @OneToMany(mappedBy = "expense")
    private List<Split> splits;

    // Getters and setters
}
