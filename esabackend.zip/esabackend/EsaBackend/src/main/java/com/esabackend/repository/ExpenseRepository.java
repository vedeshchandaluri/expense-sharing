// File: UserRepository.java
package com.esabackend.repository;

import com.esabackend.entity.Expense;
import com.esabackend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExpenseRepository extends JpaRepository<User, Long> {

	Expense save(Expense expense);}
