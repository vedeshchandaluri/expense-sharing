package com.esabackend.controller;

import com.esabackend.entity.Group;
import com.esabackend.entity.User;
import com.esabackend.repository.GroupRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/groups")
public class UserController {

    private final GroupRepository groupRepository;

    public UserController(GroupRepository groupRepository) {
        this.groupRepository = groupRepository;
    }

    @PostMapping
    public Group createGroup(@RequestBody Group group) {
        return groupRepository.save(group);
    }

    @GetMapping
    public List<User> getAllGroups() {
        return groupRepository.findAll();
    }
}
