package com.esabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsaBackendApplication.class, args);
	}

}
