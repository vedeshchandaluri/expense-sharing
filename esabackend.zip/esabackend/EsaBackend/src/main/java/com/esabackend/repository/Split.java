// File: UserRepository.java
package com.esabackend.repository;

import com.esabackend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Split extends JpaRepository<User, Long> {}
