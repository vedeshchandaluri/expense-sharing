package com.esabackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
